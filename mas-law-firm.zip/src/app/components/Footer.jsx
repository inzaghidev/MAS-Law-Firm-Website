import { Phone, Mail, MapPin, MessageCircle } from "lucide-react";
import logo from "../../assets/mas-law-firm-logo-new-white.png";

export function Footer() {
  return (
    <footer id="kontak" className="bg-[#191919] text-white py-16">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <img src={logo} alt="M.A.S Law Firm" className="h-16" />
            </div>
            <p className="text-slate-400 leading-relaxed">
              Mitra terpercaya Anda dalam hukum korporasi dan layanan hukum
              profesional.
            </p>
          </div>
          <div>
            <h4 className="mb-5 text-[#AE8737]">Informasi Kontak</h4>
            <div className="space-y-4 text-slate-400">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 mt-1 flex-shrink-0 text-[#AE8737]" />
                <span>
                  Graha Citra Unit BC, Ruko Estrela, Banjar Wijaya No.6, Cipete,
                  Kec. Pinang, Kota Tangerang, Banten 15144 Indonesia
                </span>
              </div>
            </div>
          </div>
          <div>
            <h4 className="mb-5 text-[#AE8737]">Hubungi Kami</h4>
            <div className="space-y-4 text-slate-400">
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#AE8737]" />
                <span>+62 895 3040 7021</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#AE8737]" />
                <span>kantorpengacaramas@gmail.com</span>
              </div>
              <div className="flex items-center gap-3">
                <MessageCircle className="w-5 h-5 text-[#AE8737]" />
                <a
                  href="https://wa.me/6289530407021"
                  className="hover:text-white transition-colors"
                >
                  WhatsApp: +62 895 3040 7021
                </a>
              </div>
            </div>
          </div>
          <div>
            <h4 className="mb-5 text-[#AE8737]">Jam Operasional</h4>
            <div className="text-slate-400 space-y-2 leading-relaxed">
              <p>Senin - Jumat</p>
              <p className="mb-3">09.00 - 18.00 WIB</p>
              <p>Sabtu</p>
              <p>09.00 - 14.00 WIB</p>
            </div>
          </div>
        </div>
        <div className="border-t border-[#2a2a2a] pt-8 text-center text-slate-400">
          <p>&copy; 2026 M.A.S. Law Firm. All Right Reserved.</p>
        </div>
      </div>
    </footer>
  );
}
